$(".burger").on("click", function () {
    $(".fas, nav").toggleClass("off");
})



